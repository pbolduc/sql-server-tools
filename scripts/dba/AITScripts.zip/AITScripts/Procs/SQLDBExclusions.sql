use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLDBExclusions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLDBExclusions]
GO
----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------

CREATE TABLE [dbo].[SQLDBExclusions] (
	[name] [sysname] NOT NULL 
) ON [PRIMARY]
GO

