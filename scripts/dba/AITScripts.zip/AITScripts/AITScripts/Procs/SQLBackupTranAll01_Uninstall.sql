use msdb
go


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupTranAll01]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupTranAll01]
GO

