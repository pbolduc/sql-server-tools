use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLDBUpdateStatsExclusions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLDBUpdateStatsExclusions]
GO
