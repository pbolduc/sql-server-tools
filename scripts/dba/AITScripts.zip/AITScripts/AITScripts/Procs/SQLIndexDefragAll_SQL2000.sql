USE MSDB
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragAll_SQL2000]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLIndexDefragAll_SQL2000]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


/**************************************************************************************
 Purpose	:  The Purpose of this Stored Procedure is to defrag Indexes in SQL 2005 user databases.
	                      


Date Created	: May 17, 2006

Modification History:
Date          	Who              What

=============  ===============  ====================================      
*/



CREATE PROCEDURE dbo.SQLIndexDefragAll_SQL2000
			@DBName VARCHAR(80)=NULL,
			@TableName VARCHAR(100)=NULL,
			@maxfrag DECIMAL =10.0
	

AS

SET NOCOUNT ON


DECLARE @objectid  INT
DECLARE @indexid   INT
DECLARE @indexname VARCHAR(255)
DECLARE @StrSQL NVARCHAR(2000)
DECLARE @execstr NVARCHAR(2000)
DECLARE @OutputMessage NVARCHAR(2000)
DECLARE @schmaName NVARCHAR(80)
DECLARE @frag DECIMAL
DECLARE @tblName VARCHAR(100)
DECLARE @OuterLoop INT
DECLARE @InnerLoop INT
DECLARE @InnerLoop2 INT
DECLARE @sDbname VARCHAR(80)
DECLARE @SQLCommand  varchar(2000)
DECLARE @rc            int
DECLARE @LSrc          int
DECLARE @SQLrc         int
DECLARE @DatabaseName VARCHAR(50)
DECLARE @ErrorText varchar(200)
DECLARE @Errormessage VARCHAR(400)

--Create the table

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragCommands]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLIndexDefragCommands]

CREATE TABLE [dbo].[SQLIndexDefragCommands] (
	[DBName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DefragCommand] [varchar] (2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Process] [int] NULL 
) ON [PRIMARY]





--Another table to store table names.
CREATE TABLE #TableList (Tabname VARCHAR(80))

--Create a table to store databaseNames.
CREATE TABLE #TempDBList
             (DBName VARCHAR(80),
              Process INT DEFAULT 0
	 )

--Create a Temp table to store
-- the table Names

CREATE TABLE #TempTableList
			 (DatabaseName VARCHAR(80),
			  SchemaName VARCHAR(80),
			  TableName VARCHAR(80),
		     	   Process INT DEFAULT 0		  
			  )


--Create table name to store indexes
CREATE TABLE #fraglist
		 (DatabaseName VARCHAR(80),
		 ObjectName [char] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		 ObjectId int NULL ,
		 IndexName char (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		 IndexId int NULL ,
		 Lvl int NULL ,
		 CountPages int NULL ,
		 CountRows int NULL ,
		 MinRecSize int NULL ,
		 MaxRecSize int NULL ,
		 AvgRecSize int NULL ,
		 ForRecCount int NULL ,
		 Extents int NULL ,
		 ExtentSwitches int NULL ,
		 AvgFreeBytes int NULL ,
		 AvgPageDensity int NULL ,
		 ScanDensity decimal(18, 0) NULL ,
		 BestCount int NULL ,
		 ActualCount int NULL ,
		 LogicalFrag decimal(18, 0) NULL ,
		 ExtentFrag decimal(18, 0) NULL ,
		 Status INT DEFAULT 0
		 ) 

--Check If dbname is passed as null and a table is passed. 
--Raise an error in that situation.

SET @ErrorMessage='Reindexing Requires a Database Name.In order to reindex single or multiple tables'+CHAR(13)+CHAR(10)
    		          +'both the database and table names must be passed.'

IF (@DBNAME IS NULL AND @TableName IS NOT NULL)
BEGIN
	RAISERROR (@Errormessage,16,1)
	RETURN
END



--Section I. Prepare the commands for the IndexDefrag.

IF @DBName IS NULL
BEGIN

	INSERT INTO #TempDBList(DBName) 
	SELECT [NAME] AS DBName FROM master.dbo.sysdatabases AS A
	WHERE [NAME] NOT IN ('master','msdb','tempdb','Adventureworks','model','pubs')
	AND status &512 = 0
	AND   isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
	AND    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
	AND NOT EXISTS (SELECT B.[NAME]
   		     FROM msdb..SQLDBIndexDefragExclusions b
  		     WHERE A.[NAME] = b.[NAME])
	ORDER BY [Name] ASC

END

ELSE
BEGIN



	INSERT INTO #TempDBList(DBName) 
	SELECT [NAME] AS DBName FROM master.dbo.sysdatabases AS A
	WHERE [NAME] NOT IN ('master','msdb','tempdb','Adventureworks','model','pubs')
	AND status &512 = 0
	AND   isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
	AND    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
	AND [Name]=@DBName

END

--Loop over the databases
DECLARE DBCursor CURSOR
FOR SELECT DBNAME
        FROM #TempDbList
       WHERE Process=0

OPEN DBCursor

FETCH NEXT FROM DBCursor INTO @sDbname 

--Save the fetch status to a variable
SELECT @OuterLoop = @@FETCH_STATUS


WHILE @OuterLoop = 0
BEGIN

	
	SELECT @StrSQL = N'SELECT ' +''''+ @sDbName +'''' +'AS DatabaseName, ' + 'QUOTENAME(''dbo'') As SchemaName, QUOTENAME([NAME]) As TableName  FROM ' + @sDbName +'.'+'dbo.sysobjects where type = ''U'' and uid = 1 AND [NAME] NOT LIKE ''dt%'''

	

	INSERT INTO #TempTableList 
		           (DatabaseName,
		            SchemaName,
		            TableName)
	EXEC sp_executesql @StrSQL
	

	IF @TableName IS NULL
	BEGIN
		  DECLARE TableCursor CURSOR FOR
		  SELECT DatabaseName,
			   SchemaName,
                  	 	   TableName 
		  FROM #TempTableList
		  WHERE Process=0
		  ORDER BY TableName ASC
	END
	ELSE
		 BEGIN
	  		 INSERT INTO #TableList (Tabname)
			 SELECT TABLENAME
			 FROM dbo.fnCSV_To_Table(@TableName)

			DECLARE TableCursor CURSOR 
			FOR SELECT DatabaseName,
				   SchemaName,
				   TableName 
		    	FROM  #TempTableList
	        		WHERE TableName IN 
 					(SELECT QUOTENAME(TabName) FROM #TableList)
			ORDER BY TableName ASC

		END
	
			OPEN TableCursor

			FETCH NEXT FROM TableCursor INTO @sdbName,@schmaName,@tblName

		 	--Save fetch status into local variable
		              SELECT @InnerLoop = @@FETCH_STATUS

			WHILE @InnerLoop = 0
		BEGIN

			 SELECT @StrSQL = N'USE ' + quotename(@sDbname, '[') + N'; DBCC SHOWCONTIG('''+ @schmaName + '.' + @tblName +''') WITH TABLERESULTS,ALL_INDEXES, NO_INFOMSGS;' 
			
								
			 INSERT INTO SQLIndexDefragCommands (DBName,DefragCommand)
			 VALUES (@sdbName,@StrSQL)
				
			UPDATE #TempTableList
			SET Process = 1
			WHERE DatabaseName = @sDbname  
			AND Process=0					

			FETCH  NEXT FROM TableCursor INTO @sdbName,@schmaName,@tblName
	
			SELECT @InnerLoop = @@FETCH_STATUS
	
								
		END

		    CLOSE TableCursor
		    DEALLOCATE TableCursor

		
		--Update the processed database status
		
		UPDATE #TempDbList 
		SET Process = 1
		WHERE DBName = @sDbname  
		AND Process=0
				 

FETCH NEXT FROM DBCursor into @sDbname


 SELECT @OuterLoop = @@FETCH_STATUS


END

CLOSE DBCursor
DEALLOCATE DBCursor

--Section II. Get the commands from the IndexDefrag table and execute them.

DECLARE SQLCommand_Cursor CURSOR
FOR
select DBName,DefragCommand 
from msdb.dbo.SQLIndexDefragCommands
order by DBName ASC


OPEN SQLCommand_Cursor

FETCH NEXT FROM SQLCommand_Cursor 
INTO @DBName
    ,@SQLCommand

WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
     
      INSERT INTO  #fragList(ObjectName,ObjectId,Indexname,IndexID,
			     Lvl,CountPages,Countrows,MinRecSize,MaxRecsize,
			     AvgRecSize,ForRecCount,Extents,ExtentSwitches,
			     AvgFreeBytes,AvgPageDensity,ScanDensity,BestCount,
			     ActualCount,LogicalFrag,ExtentFrag)
      EXEC (@SQLCommand)

      SELECT @SQLrc = @@error
   
      
      -- check return code from standard operation or extended proc
      IF @SQLrc = 0
      BEGIN


	 UPDATE #fragList
	 SET DatabaseName=@DBName
	 WHERE DatabaseName IS NULL

	  DELETE FROM msdb.dbo.SQLIndexDefragCommands
	  WHERE DefragCommand = @SQLCommand
	  AND  DBName =@DBName


   END

   	
   END
   
	FETCH NEXT FROM SQLCommand_Cursor 
	INTO @DBName,@SQLCommand
END
CLOSE      SQLCommand_Cursor
DEALLOCATE SQLCommand_Cursor

--Section III. Defrag all the tables in the databases passed.

DECLARE ind_Cursor  CURSOR FOR
		SELECT DatabaseName,ObjectName, ObjectId, Indexname, LogicalFrag
		FROM #fraglist
		WHERE LogicalFrag >= ISNULL(@maxfrag,10)
		AND indexid NOT IN (0,255)
		AND Status=0
		
		-- AND INDEXPROPERTY (ObjectId, IndexName, 'IndexDepth') > 0


		-- Open the cursor
			OPEN ind_Cursor

			-- loop through the indexes
			FETCH NEXT FROM ind_Cursor INTO @sdbName,@tablename, @objectid, @indexname, @frag

			--Save fetch status into local variable
		              SELECT @InnerLoop2 = @@FETCH_STATUS

			 WHILE @InnerLoop2 = 0
			BEGIN

				
				SELECT @execstr=N'DBCC INDEXDEFRAG (' + RTRIM(@sdbname) + ','+ QUOTENAME(RTRIM(@tablename),'[') + ',' + QUOTENAME(RTRIM (@indexname)) + ')' +' WITH NO_INFOMSGS' 			
				SELECT @OutputMessage=N'DBCC INDEXDEFRAG (' + RTRIM(@sdbname) + ','+ QUOTENAME(RTRIM(@tablename),'[') + ',' + QUOTENAME(RTRIM (@indexname)) + ')' 
				--SELECT @execstr = 'DBCC INDEXDEFRAG (0, ' +RTRIM(@sdbname) + ',' +QUOTENAME(RTRIM(@tablename),'[') + ',' + RTRIM(@indexid) + ')'

								
				  				 
				   PRINT (@OutputMessage)+' Completed Successfully...'
				   EXEC sp_executesql @execstr
				  
				
				
		          	     UPDATE #fraglist
				     SET Status=1
			             WHERE Status=0
			             AND DatabaseName=@sdbName
 	  		       	     AND objectName=@tableName
			             AND objectID=@objectID
			             AND IndexName=@indexName
			   
			   FETCH NEXT FROM ind_Cursor  INTO @sdbName,@tablename, @objectid, @indexname, @frag

			 SELECT @InnerLoop2 = @@FETCH_STATUS 

			END
			
			-- Close and deallocate the cursor
			CLOSE ind_Cursor
			DEALLOCATE ind_Cursor
    




DROP TABLE #TableList
DROP TABLE #TempTableList
DROP TABLE #TempDBList
DROP TABLE #fragList
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

