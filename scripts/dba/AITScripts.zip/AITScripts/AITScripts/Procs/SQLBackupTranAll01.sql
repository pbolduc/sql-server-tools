use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupTranAll01]') 
			and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupTranAll01]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





CREATE PROCEDURE SQLBackupTranAll01 
 @compress      varchar(20)  = 'nocompress'
,@drive         varchar(255) = 'F:\MSSQL\Tran'
,@encryptionkey varchar(255) = NULL
,@desc          varchar(20)  = 'SQL Tran Log Backup'
,@threads       varchar(20)  = '3'
,@priority      varchar(20)  = 0
,@latency       varchar(20)  = 0


AS


-- 03/17/2006.
DECLARE @jobId uniqueidentifier 
DECLARE @sql_job varchar(1000) 

----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations
----------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
--  This proc is paired with SQLBackupTranAll02 (this job prepars commands, 02 executes them)
--
--  This procedure Goes through every non READONLY non excluded database on the server
--  if a TRAN dump device does not exist it creates one (for standard SQL tran backups)
--  then it runs a Tran backup.  If the last db backup completed was a full backup, then the log 
--  dump device is initialized.
--
--  Databases listed in the BackupExclusions table are skipped
--
--  Parmeters:
--     @compress (default=nocompress)  
--         Causes procedure to use SQLLiteSpeed compression or Standard SQL BAckup
--     @drive (default=F)
--         Specifies which drive and path (e.g. e:\sql\tran) backups will be placed on.
--     @encryptionkey (default=null)
--         Specifies an encryption string for database
--     @desc (default=SQL Tran Log Backup)
--         SQLLIteSpeed description to be stored with the backup.
--     @threads (default=3) Valid values 1,2,3 or 0.
--         Determines the number of threads used for the backup. 
--         Best results have been identified at 2-3 for a multi processor server. 
--         Use n-1 threads, for n processor server.
--     @priority (default=0) Valid values 1,2,3 or 0.
--         Enables the priority of a SQLLiteSpeed backup to be increased to 1, 2 or 3
--         This setting could impact other processes so the default is zero.
--     @latency (default=0) Valid Levels 0 through to 30.
--         This value is used to determine what latency level 
--         will be used for the backup. This command will slow down the backup and in effect 
--         reduce the CPU and I/O levels of the backup
--     @init (default=0) 1 or 0.
--         This value is used to determine if the tran log backup file will be
--         initialized.  This is determined by the most recent backup type.
--
--    NOTE ABOUT ERROR CHECKING EXTENDED STORED PROCEDURES
--      Since an XP cannot be executed from within a string and still return a
--      valid error message, we have to format the string to load the return code
--      into a table (SQLBackupTranAll02XpResult) for reference by calling proc (SQLBackupTranAll02).
------------------------------------------------------------------------------------
SET QUOTED_IDENTIFIER ON 
SET ANSI_NULLS ON 
DECLARE @DBName	   VARCHAR(100)
       ,@SQLString VARCHAR(2000)

DECLARE @XSQLSTring varchar(2000)
       ,@BackupPath varchar(2000)
       ,@Init       varchar(10)
       ,@LSInit     varchar(10)
       ,@rc         int
       ,@PhysicalPath varchar(1000)	
-- This table holds the prepared log backup commands for execution by SQLBackupTranAll02
if exists (select * from msdb.dbo.sysobjects where id = object_id(N'SQLBackupTranCommands') 
			and OBJECTPROPERTY(id, N'IsUserTable') = 1)
Begin
  drop table [SQLBackupTranCommands]
End
CREATE TABLE msdb.dbo.SQLBackupTranCommands 
  (backupCommandSeq  int   
  ,backupCommand     varchar(2000) NULL) 

Create table #NewBackupStandardPath
   (FileExists int
  , FileIsDir  int
  , ParentDirExists int)


-- check backup path
SELECT @XSQLSTring = 'master..xp_fileexist "'+@drive+'"'
INSERT #NewBackupStandardPath EXEC  (@XSQLString)

--    set backup path variable
SELECT @BackupPath = @drive + '\'

--PRINT 'The Backuppath is ' + CONVERT(VARCHAR(20),@BackupPath)



-- if neither old nor new path exists 
--    create one using new standard


If (select ParentDirExists + FileIsDir 
    from #NewBackupStandardPath) != 2

BEGIN

	SET @sql_job='md ' + @drive

	EXEC msdb.dbo.sp_add_job @job_name = 'SQLTranAll01MakeDir', 
		  		      @enabled  = 1, 
		  		      @start_step_id = 1, 
				      @owner_login_name='sa',
		  		      @job_id = @jobId OUTPUT 
	
	EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, 
			     		@step_name = 'Create Tran log Folder', 
	 	  		     	@step_id = 1, 
			     		@subsystem = 'CMDEXEC', 
			     		@command = @sql_job 
	
	EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId
	
	EXEC msdb.dbo.sp_start_job @job_id = @jobId,@output_flag=0 

END



-- Start :Modified by Brian Kang for checking the existence of 'log_shipping_databases'

if exists (select * from sysobjects where name = 'log_shipping_databases') 



DECLARE DB_Cursor CURSOR
FOR
-- Create cursor, omit read-only, offline, logshipping and DBs with Simple Recovery mode.


	select a.name
	from   master..sysdatabases a
	where  isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
	and    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsTruncLog'),0) = 0
	and    name != 'tempdb'
and    not exists
	  (select b.name
	   from   msdb..SQLDBTranExclusions b
	   where  a.name = b.name)

and    not exists
  (select c.Database_name
   from   msdb..log_shipping_databases c
   where  a.name = c.database_name)
and    not exists
	   (select cmd 
		from master..sysprocesses
		where cmd = 'BACKUP DATABASE'
		and   dbid = db_id(a.name))


else 

DECLARE DB_Cursor CURSOR
FOR

	select a.name
	from   master..sysdatabases a
	where  isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
	and    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
	and    isnull(databaseproperty(a.name,'IsTruncLog'),0) = 0
	and    name != 'tempdb'
	and    not exists
	  (select b.name
	   from   msdb..SQLDBTranExclusions b
	   where  a.name = b.name)

	and    not exists
	   (select cmd 
		from master..sysprocesses
		where cmd = 'BACKUP DATABASE'
		and   dbid = db_id(a.name))

-- End: Modified by Brian Kang for checking the existence of 'log_shipping_databases'

   
OPEN DB_Cursor

FETCH NEXT 
FROM DB_Cursor 
INTO @DBName 
   
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
     -- Determine the Tran log INIT or NOINIT option based on 
     --  what kind of backup was completed last.
     select @INIT =  CASE type 
                WHEN 'D' 
                  then 'INIT' 
                ELSE null 
                END 
     from msdb..backupset 
     where backup_finish_date = 
          (select max(backup_finish_date) 
           from msdb..backupset 
           where database_name = @DBName)
     and   database_name = @DBName
     and   Type = 'D'

     -- Add Tran dump device if it does not exist 
     IF NOT EXISTS (select * from master..sysdevices where name = @DBName+'_Tran')
      and @compress != 'compress' 
     BEGIN
        SELECT @SQLString = 'EXEC sp_addumpdevice "disk", "'
               +@DBName+'_TRAN", "'+@BackupPath+@DBName+'_Tran.BAK"'
        insert into msdb..SQLBackupTranCommands values  (1,@SQLString)
     END


     IF @compress != 'compress'
     -- Prepare native SQl log backup command
     begin
	SELECT @PhysicalPath = @BackupPath+@DBName+'_Tran.BAK'
        SELECT @SQLString = 'BACKUP TRAN ['+@DBName+'] TO ['+@DBName+'_TRAN] WITH STATS,'+IsNull(@INIT,'NOINIT')
     END
     ELSE
     -- Prepare SQLLiteSpeed log backup command
     begin
	 SELECT @PhysicalPath = @BackupPath+@DBName+'_Tran.lsb'
         if @Init = 'INIT'
         begin
            select @LSInit = 1
         end
         else
         begin
            select @LSInit = 0
         end

         SELECT @SQLString = 'declare @rc int;exec @rc = master..xp_backup_log @database = ['+@DBName + ']'
                 + ", @filename = '" 
                       +@BackupPath 
                       +@DBName+ "_Tran.lsb'"
                 + ", @desc = '" 
                       +@desc + "'"
                 + ", @init = " 
                       +@LSInit 
        IF @encryptionkey is not null
          BEGIN
            SELECT @SQLString = @SQLString+
                + ", @encryptionkey = '" 
                      +@encryptionkey + "'"
          END


         SELECT @SQLString = @SQLString+
                 + ", @threads = " 
                       +@threads  
                 + ", @priority = " 
                       +@priority  
                 + ';insert into SQLBackupTranAll02XpResult values (@rc)'     END

         
    insert into msdb..SQLBackupTranCommands values  (2,@SQLString)
--Call the Rename SP if  the Tlog is being initialized
    if @INIT = 'INIT' -- Initialize is true
	begin
		exec SQLRenameTlogBackupFile @DBName,@PhysicalPath
	end
   END
   FETCH NEXT 
   FROM DB_Cursor 
   INTO @DBName     
END
CLOSE      DB_Cursor
DEALLOCATE DB_Cursor
GO

--Meher 03/20/2006 Drop the Job that has been created.

--Delete the job.


WAITFOR DELAY  '000:00:05'



IF EXISTS (SELECT NAME FROM msdb.dbo.sysjobs WHERE Name='SQLTranAll01MakeDir')
BEGIN
	 EXEC msdb.dbo.sp_delete_job @job_name = 'SQLTranAll01MakeDir'


END


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

