USE MSDB
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fnCSV_To_Database]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[fnCSV_To_Database]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/**************************************************************************************
 Purpose:  The Purpose of this User Defined fucntion is to separate 
	   a comma separated value list and create a Database list
           based on that list and return the table to the calling process.


Date Created: July 07, 2006

Modification History:
Date          	Who              What

=============  ===============  ====================================      
*/


CREATE  FUNCTION [dbo].[fnCSV_To_Database] (@List varchar(1000))  

RETURNS @retListDB TABLE (DBName varchar(80) NULL)  AS
BEGIN

   -- table variable to hold accumulated results

   DECLARE @ListDB TABLE (DatabaseName VARCHAR(80) NULL)
   DECLARE @Pos int
   DECLARE @NextPos int
   DECLARE @ListLen int

-- Get first value

SET @List=@List + ','
SET @ListLen=LEN(@List)
SET @Pos=CHARINDEX(',',@List) 

--Check if the position is greater than zero.

IF  (@Pos > 0 )
BEGIN
	INSERT INTO @ListDB (DatabaseName)
	VALUES (convert(VARCHAR(80),substring(@List,1,@Pos-1)))
END
ELSE
BEGIN
	INSERT INTO @ListDB (DatabaseName)
	VALUES (convert(VARCHAR(80),substring(@List,1,@ListLen-1)))
END

SET @NextPos=CHARINDEX(',',@List,@Pos+1)

--Loop through to find all other occurances

WHILE @NextPos>0
BEGIN

	INSERT INTO @ListDB (DatabaseName)
	values (convert(VARCHAR(80),substring(@List,@Pos+1,@NextPos-@Pos-1)))

	SET @Pos=CHARINDEX(',',@List,@Pos+1)  
	SET @NextPos=CHARINDEX(',',@List,@Pos+1)
END


   
-- copy to the result of the function the required columns
INSERT INTO @retListDB
SELECT DatabaseName
FROM @ListDB
RETURN

END




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


