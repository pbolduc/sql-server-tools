use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupAll02]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupAll02]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [dbo].[SQLBackupAll02] 
AS
----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations
----------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
--  This procedure processes backup/verify commands that were
--  prepared in SQLBackupAll01.
-------------------------------------------------------------------------------------

declare @SQLCommand    varchar(2000)
       ,@SQLCommandSeq int
       ,@rc            int
       ,@LSrc          int
       ,@SQLrc         int





-- this table holds the result of extended stored procedure execution
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupAll02XpResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
  drop table [dbo].[SQLBackupAll02XpResult]
end
create table SQLBackupAll02XpResult (xpresult int)



DECLARE SQLCommand_Cursor CURSOR
FOR
select backupCommandSeq,backupCommand 
from msdb..SQLBackupCommands
order by backupCommandSeq


OPEN SQLCommand_Cursor

FETCH NEXT 
FROM SQLCommand_Cursor 
INTO @SQLCommandSeq 
    ,@SQLCommand

-- Cursor through the commands, execute them, remove them from
-- table if executed successfully.   
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
      DELETE FROM SQLBackupAll02XpResult
      EXEC (@SQLCommand)
      SELECT @SQLrc = @@error
      SELECT @LSrc  = max(xpresult) from SQLBackupAll02XpResult
      
	 -- check return code from standard operation or extended proc
      IF @SQLrc = 0
      AND ISNULL((select max(xpresult) from SQLBackupAll02XpResult),0) = 0
      BEGIN
					
	   delete from msdb..SQLBackupCommands
           where backupCommand = @SQLCommand
      END
      
 END

FETCH NEXT 
FROM SQLCommand_Cursor 
INTO @SQLCommandSeq
    ,@SQLCommand     

END
CLOSE      SQLCommand_Cursor
DEALLOCATE SQLCommand_Cursor

GO
