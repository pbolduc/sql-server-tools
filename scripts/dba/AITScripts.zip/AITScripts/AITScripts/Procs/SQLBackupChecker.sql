USE msdb
GO

/****** Object:  StoredProcedure [dbo].[SQLBackupChecker]    Script Date: 01/04/2006 17:17:08 ******/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupChecker]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupChecker]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [dbo].[SQLBackupChecker] @hours INT
AS
----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------
-- This procedure lists databases that have not had a backup in the 
-- specified number of hours.
-- Syntax exec SQLBackupChecker 24
SET QUOTED_IDENTIFIER ON 
SET ANSI_NULLS ON 
DECLARE @DBName	VARCHAR(100)
        ,@CmdShellCmd VARCHAR(255)
	  ,@BackupReadonly int            -- Variable to store the status of the Readonly database backups
SELECT @BackupReadonly = IsBackedup from SQLRODBStatus 
IF @BackupReadonly = 0                  -- If Readonly databases are not getting backedup, join the view MostRecentBackup
BEGIN
	DECLARE DB_Cursor CURSOR
	FOR
	SELECT a.DatabaseName
	from   MostRecentBackup a
	where  BackupDate < DATEADD(hour,(@hours*-1),getdate())
	and    not exists
	(select b.name
	from   msdb..SQLDBExclusions b
	where  a.DatabaseName = b.name)
END
ELSE					         -- If Readonly databases are getting backedup, join the view MostRecentBackup_RODB
BEGIN
	DECLARE DB_Cursor CURSOR
	FOR
	SELECT a.DatabaseName
	from   MostRecentBackup_RODB a
	where  BackupDate < DATEADD(hour,(@hours*-1),getdate())
	and    not exists
	(select b.name
	from   msdb..SQLDBExclusions b
	where  a.DatabaseName = b.name)
END  
OPEN DB_Cursor

FETCH NEXT 
FROM DB_Cursor 
INTO @DBName 
      

WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN  
     SELECT @CmdShellCmd = 'MOM SQL Backup Check - It has been more than '+RTRIM(CONVERT(CHAR,@hours)) + ' hours since there has been a backup of database '+@DBName
     --print @CmdShellCmd
     RAISERROR (@CmdShellCmd,10,1) WITH LOG
   END
   FETCH NEXT 
   FROM DB_Cursor 
   INTO @DBName     
END
CLOSE      DB_Cursor
DEALLOCATE DB_Cursor


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


