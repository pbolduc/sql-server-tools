use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLDBIndexDefragExclusions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLDBIndexDefragExclusions]
GO
----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------

CREATE TABLE [dbo].[SQLDBIndexDefragExclusions] (
	[name] [sysname] NOT NULL 
) ON [PRIMARY]
GO
