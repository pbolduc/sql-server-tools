USE msdb
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupAll03]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupAll03]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[SQLBackupAll03]

AS

SET NOCOUNT ON

DECLARE @DatabaseName VARCHAR(200)
DECLARE @ErrorText varchar(4000)
DECLARE @Delimiter CHAR(1)

CREATE TABLE #DBFailedBackups
		     (BackupCommand VARCHAR(2000),
			  DBName VARCHAR(200)
			  )
 
INSERT INTO #DBFailedBackups (BackupCommand,DBName)
SELECT BackupCommand,
       LTRIM(RTRIM(SUBSTRING(BackupCommand,CHARINDEX (':',BackupCommand)+1,CHARINDEX ('''',BackupCommand,CHARINDEX (':',BackupCommand)+1)-1-CHARINDEX (':',BackupCommand)))) AS DBName
FROM msdb.dbo.SQLBackupCommands
WHERE backupcommand LIKE '%Backing up%'
AND backupCommandSeq=20
AND LTRIM(RTRIM(SUBSTRING(BackupCommand,CHARINDEX (':',BackupCommand)+1,CHARINDEX ('''',BackupCommand,CHARINDEX (':',BackupCommand)+1)-1-CHARINDEX (':',BackupCommand)))) 
     NOT IN (SELECT DBName FROM #DBFailedBackups)

IF (SELECT COUNT(*) FROM #DBFailedBackups) > 0

BEGIN

	SET @Delimiter=','

	SELECT @DatabaseName = COALESCE(@DatabaseName + @delimiter, '') + DBName  
							FROM #DBFailedBackups
						    


	SELECT @ErrorText = 'SQLBackupError.BackupFailed for Database(s): '+ RTRIM(@DatabaseName)+'.'+' Please See SQL Server Agent Job History for More Information.'

	 PRINT @errorText

	EXEC master..xp_logevent 60000, @ErrorText, informational

END


--drop the temp table
DROP TABLE #DBFailedBackups



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

