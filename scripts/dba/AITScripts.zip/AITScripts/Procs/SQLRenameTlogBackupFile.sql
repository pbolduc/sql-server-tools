use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLRenameTlogBackupFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLRenameTlogBackupFile]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.SQLRenameTlogBackupFile  @DBName varchar(100),@FileName  varchar(1000)
AS
set nocount on
SET QUOTED_IDENTIFIER ON 
SET ANSI_NULLS ON 
declare @FileExists int
	,@RenCmd  varchar(1000)
	,@DelCmd  varchar(1000)
	,@FileExtension varchar(10)
	,@NewFilename varchar(1000)

-- 03/20/2006 Declare variables to hold.

DECLARE @jobId uniqueidentifier 
DECLARE @sql_job varchar(1000) 
DECLARE @runStatus INT



select @FileExtension = substring(@filename,charindex('.',@filename,1),4)
select @Newfilename = @FileName + '_old'

--Check if _old Tranlog backup file exists
--print @Newfilename

exec master.dbo.xp_fileexist @NewFilename, @FileExists output

--print @fileexists

IF @FileExists <> 1 -- _old File does not exist
begin
	-- _old File does not exit. So rename Original file with out deleting the  _Old file'
	-- Checkig if the origial file exists'

	exec master.dbo.xp_fileexist @Filename, @FileExists output

	IF @FileExists = 1 -- Original file exists 
	begin

	--Rename the original file

		SET @sql_job='ren ' +'"'+@FileName+'"' + ' ' + @DBName +'_TRAN' + @FileExtension + '_old'
		
		EXEC msdb.dbo.sp_add_job @job_name = 'SQLRenameTlog' ,
		  		      @enabled  = 1, 
		  		      @start_step_id = 1, 
				      @owner_login_name='sa',
		  		      @job_id = @jobId OUTPUT 

		EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, 
				     		@step_name = 'Rename TLog Backup file', 
		 	  		     	@step_id = 1, 
				     		@subsystem = 'CMDEXEC', 
				     		@command = @sql_job 

		EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId

		EXEC msdb.dbo.sp_start_job @job_id = @jobId,@output_flag=0 

	    

		--03/20.2006 Commented out the following code since use of xp_cmdshell is prohibited.
		--select @RenCmd = 'master..xp_cmdshell ''rename ' + @FileName + ' ' + @DBName +'_TRAN' + @FileExtension + '_old'''
		--exec(@RenCmd)
	end		
end
ELSE -- _old File exists
begin
	-- _old File already exits. So Delete the _old file before renaming the original file
	-- Check if the origial file exists'
		--Print @filename
		--Print @Fileexists

	exec master.dbo.xp_fileexist @Filename, @FileExists output

	--print @Fileexists

	IF @FileExists = 1 --Original file exists
	begin
		-- 03/20/2006 Deleting the _old File by creating a job.
		
		SET @jobID = NULL

		SET @sql_job='Del ' +'"'+@NewFileName+'"' + ''
		
		--print @SQL_JOB

		--WAITFOR DELAY  '000:00:03'
		

		EXEC msdb.dbo.sp_add_job @job_name = 'SQLDeleteTlog' ,
		  		      @enabled  = 1, 
		  		      @start_step_id = 1, 
				      @owner_login_name='sa',
		  		      @job_id = @jobId OUTPUT 

		EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, 
				     		@step_name = 'Delete TLog Backup file', 
		 	  		     	@step_id = 1, 
				     		@subsystem = 'CMDEXEC', 
				     		@command = @sql_job 

		EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId

		EXEC msdb.dbo.sp_start_job @job_id = @jobId,@output_flag=0 

	

	--03/20.2006 Commented out the following code since use of xp_cmdshell is prohibited.
	-- Deleting the _old File

	--select @DelCmd = 'master..xp_cmdshell ''del ' + @NewFilename + ''''
	--exec(@DelCmd)	

--	Rename the original file

	     WAITFOR DELAY  '000:00:03'

  		SET @jobID = NULL 

		
		SET @sql_job='ren ' +'"'+@FileName+'"' + ' ' + @DBName +'_TRAN' + @FileExtension + '_old'

		--WAITFOR DELAY  '000:00:04'

		
		EXEC msdb.dbo.sp_add_job @job_name = 'SQLRenameOriginal' ,
			  		      @enabled  = 1, 
			  		      @start_step_id = 1, 
					      @owner_login_name='sa',
			  		      @job_id = @jobId OUTPUT 

		EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, 
					     		@step_name = 'Rename Original TLog Backup file', 
			 	  		     	@step_id = 1, 
					     		@subsystem = 'CMDEXEC', 
					     		@command = @sql_job 
	
		EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId
	
		EXEC msdb.dbo.sp_start_job @job_id = @jobId,@output_flag=0 

		--03/20/2006 Commented out the following code since use of xp_cmdshell is prohibited.
		--select @RenCmd = 'master..xp_cmdshell ''rename ' + @FileName + ' ' + @DBName + '_TRAN' + @FileExtension + '_old'''
		--exec(@RenCmd)	
	end	
end


WAITFOR DELAY  '000:00:05'

--Drop jobs
--Drop all jobs that have been created.

--AITRenameTlogBackupfile

IF EXISTS (SELECT NAME FROM msdb.dbo.sysjobs WHERE Name='SQLRenameTlog')
BEGIN
	 EXEC msdb.dbo.sp_delete_job @job_name = 'SQLRenameTlog'


END

--AITRenameDeleteTlogBackupfile

IF EXISTS (SELECT NAME FROM msdb.dbo.sysjobs WHERE Name='SQLDeleteTlog')
BEGIN
	 EXEC msdb.dbo.sp_delete_job @job_name = 'SQLDeleteTlog'


END


--AITRenameTlogOriginalFile

IF EXISTS (SELECT NAME FROM msdb.dbo.sysjobs WHERE Name='SQLRenameOriginal')
BEGIN
	 EXEC msdb.dbo.sp_delete_job @job_name = 'SQLRenameOriginal'


END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

