use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragAll]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLIndexDefragAll]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/**************************************************************************************
 Purpose	:  The Purpose of this Stored Procedure is to detect the SQL server version and call the appropriate stored                    procedure to defrag Indexes in user databases.
	                      


Date Created	: May 17, 2006

Modification History:
Date          	Who              What

=============  ===============  ====================================      
*/


CREATE PROCEDURE dbo.SQLIndexDefragAll
		 @dbName VARCHAR(80)=NULL,
		 @TableName VARCHAR(100)=NULL,
		 @Frag Float = 10.0

AS SET NOCOUNT ON

DECLARE @Version VARCHAR(255)



SELECT @Version=CASE 
		      WHEN CHARINDEX ('8.00',@@version)>0 then 'SQL Server 2000'
		      WHEN CHARINDEX ('9.00',@@version)>0 then 'SQL Server 2005'
                      ELSE 'UnKnown'
		END



IF @Version='SQL Server 2000'
BEGIN
  	EXEC SQLIndexDefragAll_SQL2000  
			@dbName=@dbName,
			@TableName=@TableName,
			@maxFrag=@Frag
END


IF @Version='SQL Server 2005'
BEGIN
  	EXEC SQLIndexDefragAll_SQL2005 
		 @dbName=@dbName,
		 @TableName=@TableName,
		 @Frag=@Frag
END


	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

