use msdb
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MostRecentBackup]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[MostRecentBackup]
GO
----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------



-- create view with most recent backup for non read only databases
CREATE VIEW MostRecentBackup
AS
select   a.database_name as 'DatabaseName', max(backup_finish_date) as 'BackupDate'
from     msdb..backupset a
where    a.type in ('I','D')
and exists 
  (select *
   from   master..sysdatabases b
   where  a.database_name = b.name
   and    isnull(databaseproperty(b.name,'isReadOnly'),0) = 0
   and    isnull(databaseproperty(b.name,'isOffline'),0)  = 0)
and not exists
  (select * 
   from SQLDBExclusions c
   where a.database_name = c.name)
group by a.database_name


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

