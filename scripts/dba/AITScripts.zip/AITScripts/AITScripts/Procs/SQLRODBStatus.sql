use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLRODBStatus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLRODBStatus]
GO
----------------------------------------------------------------------------------------------
--  Author MGP/ Microsoft SQL Operations 
----------------------------------------------------------------------------------------------

CREATE TABLE [dbo].[SQLRODBStatus] (
	[IsBackedUp] [int] NOT NULL 
) ON [PRIMARY]
GO