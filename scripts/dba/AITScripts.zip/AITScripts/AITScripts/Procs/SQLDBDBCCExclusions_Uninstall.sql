use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLDBDBCCExclusions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLDBDBCCExclusions]
GO
