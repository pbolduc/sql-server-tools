use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLDBUpdateStatsExclusions]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLDBUpdateStatsExclusions]
GO
----------------------------------------------------------------------------------------------
--  Author MGP / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------

CREATE TABLE [dbo].[SQLDBUpdateStatsExclusions] (
	[name] [sysname] NOT NULL 
) ON [PRIMARY]
GO
